const mongoose = require('mongoose');
const Location = require('./models/location');

mongoose.connect('mongodb://localhost:27017/Outdoors', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", () => {
    console.log("Database connected");
});

const seedDB = async() => {
    await Location.deleteMany({});
    const l = new Location({title: 'Tropical Island'});
}