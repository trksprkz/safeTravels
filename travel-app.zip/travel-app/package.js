const express = require('express');
const path = require('path');
const mongoose = require('mongoose');
const Location = require('./models/location');

mongoose.connect('mongodb+srv://notetation.auf8q.mongodb.net/myFirstDatabase', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

const db = mongoose.connection;
db.on("error", console.error.bind(console, "connection error:"));
db.once("open", () => {
    console.log("Database connected");
});

const app = express();

app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));


app.get('/', (req, res) => {
    res.render('home')
});
app.get('/location', async (req, res) => {
    const loc = new Location({title: 'Atlanta', description: 'Oh yes... the great outdoors'})
    await loc.save();
    res.send(loc);
});
app.listen(3000, () => {
    console.log('Serving port 3000')
})